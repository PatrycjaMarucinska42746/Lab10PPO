DATA_PATH = "data/animals.txt"
FAMILIES_PATH = "data/families.txt"